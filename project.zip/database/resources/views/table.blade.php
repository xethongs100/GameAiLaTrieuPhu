@extends('layout')

@section('table_content')
    @include('template.wrapper')
@endsection