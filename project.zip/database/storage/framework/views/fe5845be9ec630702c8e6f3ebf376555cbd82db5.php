<div class="wrapper">
            <div class="container-fluid">

                <!-- start page title -->
                <div class="row">
                    <div class="col-12">
                        <div class="page-title-box">
                            <div class="page-title-right">
                                <ol class="breadcrumb m-0">
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Upvex</a></li>
                                    <li class="breadcrumb-item"><a href="javascript: void(0);">Tables</a></li>
                                    <li class="breadcrumb-item active">Datatables</li>
                                </ol>
                            </div>
                            <h4 class="page-title">Datatables</h4>
                        </div>
                    </div>
                </div>     
                <!-- end page title --> 

                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <h4 class="header-title">Basic Data Table</h4>
                                <p class="text-muted font-13 mb-4">
                                    DataTables has most features enabled by default, so all you need to do to use it with your own tables is to call the construction
                                    function:
                                    <code>$().DataTable();</code>.
                                </p>

                                <table id="basic-datatable" class="table dt-responsive nowrap">
                                    <thead>
                                        <tr>
                                            <th>Id</th>
                                            <th>Username</th>
                                            <th>Password</th>
                                            <th>Email</th>
                                            <th>Avatar</th>
                                            <th>Highest point</th>
                                            <th>Credit</th>
                                            <th></th>
                                        </tr>
                                    </thead>                              
                                    <tbody>
                                        <tr>
                                           
                                            <td>handeptrai</td>
                                            <td>handeptrai@123</td>
                                            <td>xethongs100@gmail.com</td>
                                            <td>profile.jpg</td>
                                            <td>250</td>
                                            <td>100$</td>
                                            <td>
                                                <button type="button" class="btn btn-purple waves-effect waves-light"><i class="fe-file-plus"></i></button>
                                                <button type="button" class="btn btn-warning waves-effect waves-light"><i class="mdi mdi-settings"></i></button>
                                                <button type="button" class="btn btn-danger waves-effect waves-light"><i class="mdi mdi-close"></i></button>
                                            </td>
                                        </tr>
                                    </tbody>
                                </table>

                            </div> <!-- end card body-->
                        </div> <!-- end card -->
                    </div><!-- end col-->
                </div>
                <!-- end row-->     
            </div> <!-- end container -->
</div><?php /**PATH C:\Users\USER\Desktop\Laravel\database\resources\views/template/wrapper.blade.php ENDPATH**/ ?>