<?php

use Illuminate\Database\Seeder;

class NguoiChoi extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('nguoi_chois')->insert([
            ['username'=>'hienxinhdep','password'=>'123456','email'=>'hiendepgai@gmail.com','avatar'=>'2.jpg','highest_point'=>200,'credit'=>100],
            ['username'=>'nguyetxinhdep','password'=>'123456','email'=>'nguyetdepgai@gmail.com','avatar'=>'3.jpg','highest_point'=>300,'credit'=>500],
            ['username'=>'tramxinhdep','password'=>'123456','email'=>'tramdepgai@gmail.com','avatar'=>'4.jpg','highest_point'=>400,'credit'=>300]
        ]);
    }
}
